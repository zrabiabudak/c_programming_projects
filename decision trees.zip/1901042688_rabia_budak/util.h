#ifndef _UTIL_H_
#define _UTIL_H_

#define CLOSE_ENOUGH 0.001

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, int s, int w);

char dt1a(double PL,double SL,double PW,double SW);
char dt1b(double PL,double SL,double PW,double SW);

double dt2a(double X1,double X2,double X3,unsigned int X4,unsigned int X5);
double dt2b(double X1,double X2,double X3,unsigned int X4,unsigned int X5);


/*the prototype of the functions implementing the decision trees for the third problem */
double dt3a(int d_o_w, int m_o_y, int d_o_m, double h_o_d, unsigned int finish );

double dt3b(int d_o_w, int m_o_y, int d_o_m, double h_o_d, unsigned int finish );


#endif /* _UTIL_H_ */
