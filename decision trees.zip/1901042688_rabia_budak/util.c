#include <stdio.h>
#include <stdlib.h>
#include "util.h"

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, int s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
}

char dt1a(double PL,double SL,double PW,double SW){
 
	if(PL<2.45)
	return 's';		/* s = setosa */
	
	if(PW<1.75 && PL<4.95 && PW<1.65)
	return 'v';		/* v = versicolor */

	return 'r';		/* virginica */
	
}

char dt1b(double PL,double SL,double PW,double SW){
 
	if(PL<2.55)
	return 's';		/* s = setosa */
	
	if(PW<1.69 && PL<4.85 )
	return 'v';  			/* v = versicolor */

	return 'r';			/* virginica */
	
}
double dt2a(double X1,double X2,double X3,unsigned int X4,unsigned int X5){
	if(X1<31.5){
		if(X2>-2.5)
		return 5.0;
		
		if(X2-0.1<=X1 && X2+0.1>=X1)
		return 2.1;
		
		return -1.1;		
		
	}
	if(X3>=-1 && X3<=2)
	return 1.4;
	if(X4==1 && X5==1)
	return -2.23;
	
	return 11.0;
}

double dt2b(double X1,double X2,double X3,unsigned int X4,unsigned int X5){
	if(X1>12 && X1<22){
		if(X3>(5/3))
		return -2;
		if(X1-0.1<=X3 && X1+0.1 >=X3)
		return 1.01;
		
		return -8;
	}
	if(X4==1 && X5==1)
	return -1;
	if(X2>=-1 && X2<=2)
		return (-1/7);
		
	
		return 0.4714; /* result of root(3)/2  */
	


}

double dt3a(int d_o_w, int m_o_y, int d_o_m, double h_o_d, unsigned int finish ){ /* FOR DAY SHIFT WORKER ||| finish --> finish of day project, d_o_m --> day of month ,d_o_w -->day of week, m_o_y--> month of year, h_o_d --> hour of day */ 
	if(m_o_y==6 || m_o_y==12){	/* first 15 days of 6th of year and 12th of year it gives extra rate to work in the month */
		if(d_o_m<=15)
		return 0.5;
		
		return 1; 
	}
	if(d_o_w==3 || d_o_w== 5){  /* it gives extra rate to work 3. and 4. day of week work if hour is more than 16.30 */
	if(h_o_d>16.30)
	return 0.6;
	
	if(h_o_d>12.15 && h_o_d<13.15)	/* if the worker works during meal time */
	return 0.5;
	
	return 1;
	}
	if(d_o_w==6 || d_o_w==7)		/* if the worker works on saturday sunday */
	return 2;
	if(h_o_d>12.15 && h_o_d<13.15) 	/*  if the worker works weekend and during meal time */
	return 4;
	
	if(finish==1){		/* if the worker finished works before 12.15 */
	if(h_o_d<12.15)
	return 2;
	if(h_o_d>12.15 && h_o_d<16.30)  /* if the worker finished works between 12.15 and 16.30 */
	return 1.5;
	}
	if(h_o_d==16.30){  /* if he has not completed project at the time of check out */
		if(finish==0)
			return (-0.6);
		}	
			return 1;
		
}

double dt3b(int d_o_w, int m_o_y, int d_o_m, double h_o_d, unsigned int finish ){ /* FOR DAY SHIFT WORKER ||| finish --> finish of day project, d_o_m --> day of month ,d_o_w -->day of week, m_o_y--> month of year, h_o_d --> hour of day */ 
	if(m_o_y%5==0){ /* there are promtion in the months from 5 to mod equal to 0 of the year */
		if(d_o_m>7 && d_o_m<13)  /* if day of month between 7 and 13 it works promotion rate 0.9 */
		return 0.9;
		
		return 1;
	}
	if(d_o_w<=6){   /* if worker works weekdays and he works 5 hour in a day rate it -0.8 */
	if(h_o_d<5)
	return (-0.8);
	
	if(h_o_d>12)   /* if worker works weekdays and he works more than 12 hour in a day rate it 0.6 */
	return 0.6;
	
	return 1;
	}
	if(d_o_w>5)    /* if he works more than 5 day the rate is 2 */
	return 2;
	
	if(h_o_d>19.45)       /* if he works more than 19.45 */
	return 2.5;
	
	if(finish==0){   /* if he does not completed  rate is -2 */
	if(h_o_d>16.30)
	return -2;
	
	}
	if(h_o_d==23.59){		/*if he works until 23.59 and he does not completed he rate is -0.6 */
		if(finish==0)
			return (-0.6);
		}	
			return 1;
		
}












