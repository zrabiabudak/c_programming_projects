#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {
int select,d_o_w, m_o_y, d_o_m;
double PL, SL, PW, SW,X1,X2,X3,rate,h_o_d;
unsigned int  X4,X5,finish ;
char t;  /*result of function 1 to return char */
    /* Ask for the problem selection (1,2,3) .....  */
    
   
    while(select!=-1){
    	  printf("enter the problem selection 1,2 or 3\n");
   	  printf("enter -1 for exit");
    	  scanf("%d",&select);
    	  getchar();
   	 if(select==1){ /* Get the input from the user for the first problem,to test dt1a */
   	 	
   	 	printf("enter the  PL\n");
   	 	scanf("%lf",&PL);
   	 	printf("enter the  PW\n");
   	 	scanf("%lf",&PW);
   	 	printf("enter the  SL\n");
   	 	scanf("%lf",&SL);
   	 	printf("enter the  SW\n");
   	 	scanf("%lf",&SW);
   	 	printf("decision tree part 1 section a\n ");
    		t=dt1a(PL, SL, PW, SW);
    		if( t=='s')		 /* Compare performances and print results*/
    		printf("Setosa\n");
    		if( t=='r')
    		printf("Virginica\n");
    		if( t=='v')
    		printf("Versicolor \n");
    		
    		printf("\ndecision tree part 1 section b\n ");
    		t=dt1b(PL, SL, PW, SW);
    		if( t=='s')
    		printf("Setosa\n");
    		if( t=='r')
    		printf("Virginica\n");
    		if( t=='v')
    		printf("Versicolor \n");
    		printf("\nCongratulations you have completed first part,what part would you like to do now?\n ");
   	 }
   	 if(select==2){
   	 /* Get the input from the user for the second problem,to test dt2a */
   	printf("decision tree part 2 section a\n ");
   	 	printf("enter the  X1\n");
   	 	scanf("%lf",&X1);
   	 	printf("enter the  X2\n");
   	 	scanf("%lf",&X2);
   	 	printf("enter the  X3\n");
   	 	scanf("%lf",&X3);
   	 	printf("enter the  X4\n");
   	 	scanf("%u",&X4);
   	 	printf("enter the  X5\n");
   	 	scanf("%u",&X5);
    		rate=dt2a(X1, X2, X3, X4, X5);    /* Compare performances and print results */
    		printf("%lf",rate);
   	 
   	 printf("decision tree part 2 section b\n ");
   	 	
    		rate=dt2b(X1, X2, X3, X4, X5);
    		printf("%lf",rate);
    		printf("\nCongratulations you have completed second part,what part would you like to do now?\n ");
   	
   	 }
   	  
   	  /* In part 3, I calculated the contribution rates of a worker in a factory working extra working days and hours during the week, on weekends or outside working hours.
and I calculated the rate when he could not complete his project. */
   	  
   	else if(select==3){	
   	
   	/* Get the input from the user for the second problem,to test dt2a */
   	 	printf("enter the  d_o_w (write down the day of month you  work )\n");
   	 	scanf("%d",&d_o_w);
   	 	printf("enter the  m_o_y(write down the month of year you  work )\n");
   	 	scanf("%d",&m_o_y);
   	 	printf("enter the  d_o_m(write down the day of month you  work )\n");
   	 	scanf("%d",&d_o_m);
   	 	printf("enter the  h_o_d (write down the hour of day you  work )\n");
   	 	scanf("%lf",&h_o_d);
   	 	printf("enter the  finish(write down the 1 if you finish project otherwise 0 )\n");
   	 	scanf("%u",&finish );
   	 	printf("decision tree part 3 section a\n ");
    		rate=dt3a(d_o_w, m_o_y, d_o_m, h_o_d, finish);    /*  rate of additional salary  */
    		printf("%lf\n",rate);
    		printf("decision tree part 3 section b\n ");
   		rate=dt3b(d_o_w, m_o_y, d_o_m, h_o_d, finish);    /*  rate of additional salary  */
   		printf("%lf\n",rate);
   		printf("\nCongratulations you have completed third part,what part would you like to do now?\n ");
   	
   	 }
  	  
       
   }
    
    return 0;
}













