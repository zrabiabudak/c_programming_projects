#include<stdio.h>

#include<string.h>

#include<time.h>

#include<stdlib.h>

#define ROW 50
#define COLUMN 10
#define SIZE 15

enum compass {
   NORTH,
   SOUTH,
   EAST,
   WEST,
   NORTHEAST,
   NORTHWEST,
   SOUTHEAST,
   SOUTHWEST
}; /* diagnose of words in game board */

void words_write_to_array(char words_array[ROW][COLUMN]); /*assigns the words in the file to the array.*/
void fill_board(char board_array[SIZE][SIZE]); /* Preparing a 15x15 array */
int random_num(int num); /*get random number */
int placement_word(char board_array[SIZE][SIZE], char words_array[ROW][COLUMN]);			/* place words on board. */
int check_board(char board_array[SIZE][SIZE], char words_array[ROW][COLUMN], int, int, int, int); /* controls the game board in order to place words on board. */
int play_game(char board_array[SIZE][SIZE]);	/*start to play game*/
void random_letter(char board_array[SIZE][SIZE]);   /* adding random letters to the game */

int main() {

   int flag = 0, num_words, direction, row, column, count = 0;
   char words_array[ROW][COLUMN];
   char board_array[SIZE][SIZE];
   srand(time(NULL));
   words_write_to_array(words_array); 	/* assign words in file to an array */
   fill_board(board_array); /* Preparing a 15x15 array */

   while (count < 7) {
      /* 7 word placement in array.*/
      placement_word(board_array, words_array);
      count++;
   }
   random_letter(board_array);

   play_game(board_array); /* start the game */
}
void random_letter(char board_array[SIZE][SIZE]){	/*random letter generator to the board*/
    for(int i=0;i<SIZE;i++){
        for(int j=0;j<SIZE;j++){
           if(board_array[i][j]==' '){
            board_array[i][j]='a'+rand()%26;
             }
         }
    }
}

int play_game(char board_array[SIZE][SIZE]) {
   /*start game*/
   char user_word[10];
   int row, temp_row, temp_column, column, flag = 0, i = 0, length_word,check,
      flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0, flag5 = 0, flag6 = 0, flag7 = 0, flag8 = 0, wrong = 0, points = 0; /* flags are find out which direction the word is going. */
 
   while (points <14 && wrong < 3) {		/* to check user points and wrong */
   for (int k = 0; k < SIZE; k++) {  /* Printing the array to the terminal. */
      for (int j = 0; j < SIZE; j++) {
         printf("%c", board_array[k][j]);
      }
      printf("\n");
   }
      printf("enter coordinates and word");
      check=scanf("%d%d%s", & row, & column, user_word);	/* check scanf return value and take word and row and column */
	
	if(check==0)
	return 0;
	
	if(check==1 || check==2)
	    flag=0;
	
      length_word = strlen(user_word); /*to look at the length of the word.*/
      length_word=length_word-1;
      

      if (user_word[i] == board_array[row][column]) /* to check if the word matches. */
         flag = 1;

	if(length_word==1 || length_word==0 )
	   flag=0;

      if (flag == 1) {
         /* to check if word fits in the north direction. */
         temp_row = row;
         temp_column = column;
         while (board_array[temp_row][column] == user_word[i]) {
            /* NORTH */
            if (i == length_word) /* checking if the length of the word matches.*/
               break;

            if (temp_row == 0)
               break;

            temp_row--; /* north direction */
            i++;
         }

      }
      temp_row = row;
      temp_column = column;

      if (i == length_word && flag==1) {
         /*if the length of the word is sufficient , you found to word.*/
         flag1 = 1;
         points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         
      }

      if (flag1 == 1) {
         while (i >= 0){ /* to the north*/
            board_array[temp_row][column] = 'x';
         temp_row--;
         i--;
      }

   }
   temp_row = row;
   temp_column = column;
   i = 0;
   if (flag1 != 1 && flag == 1) {		/* SOUTH */
      while (board_array[temp_row][column] == user_word[i]) {
         

         if (i == length_word)
            break;

         if (temp_row == SIZE)
            break;

         temp_row++;
         i++;
      }
      temp_row = row;
      temp_column = column;

      if (i == length_word) {  /* if word is find user get 2 points  */
         points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         flag2 = 1;
      }

      if (flag2 == 1) {
         while (i >= 0) {
            board_array[temp_row][column] = 'x';	/* replace the word with x */
            temp_row++;
            i--;
         }

      }
      temp_row = row;
      temp_column = column;
      i = 0;
   }
   if (flag2 != 1 && flag1 != 1 && flag == 1) {
      while (board_array[row][temp_column] == user_word[i]) {
          

         if (i == length_word)
            break;

         if (temp_column == SIZE)
            break;

         temp_column++;
         i++;
      }
      if (i == length_word) {
          
         points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         flag3 = 1;
      }

      if (flag3 == 1) {
         temp_row = row;
         temp_column = column;
         while (i >= 0) {
            
            board_array[row][temp_column] = 'x';		/* replace the word with x */
            temp_column++;
            i--;
         }
      }
      i = 0;
      temp_row = row;
      temp_column = column;
   }
   if (flag2 != 1 && flag1 != 1 && flag3 != 1 && flag == 1) {
      while (board_array[row][temp_column] == user_word[i]) {
         
         if (i == length_word)
            break;

         if (temp_column == 0)
            break;

         temp_column--;
         i++;
      }
      if (i == length_word) {
          
         points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         flag4 = 1;
      }

      if (flag4 == 1) {
         temp_row = row;
         temp_column = column;
         while (i >= 0) {
             
            board_array[row][temp_column] = 'x';	/* replace the word with x */
            temp_column--;
            i--;
         }

      }
      i = 0;
      temp_row = row;
      temp_column = column;
   }
   if (flag2 != 1 && flag1 != 1 && flag3 != 1 && flag4 != 1 && flag == 1) {
      while (board_array[temp_row][temp_column] == user_word[i]) {
          

         if (i == length_word)
            break;
         if (temp_column == SIZE)
            break;
         if (temp_row == 0)
            break;

         temp_column++;
         temp_row--;
         i++;
      }
      if (i == length_word) {
              points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         flag5 = 1;
      }
      if (flag5 == 1) {
         temp_row = row;
         temp_column = column;
         while (i >= 0) {
             
            board_array[temp_row][temp_column] = 'x';		/* replace the word with x */
            temp_column++;
            temp_row--;
            i--;
         }
      }
      i = 0;
      temp_row = row;
      temp_column = column;
   }
   if (flag2 != 1 && flag1 != 1 && flag3 != 1 && flag4 != 1 && flag5 != 1 && flag == 1) {
      while (board_array[temp_row][temp_column] == user_word[i]) {
         
         if (i == length_word)
            break;

         if (temp_column == 0)
            break;
         if (temp_row == 0)
            break;

         temp_column--;
         temp_row--;
         i++;
      }
      if (i == length_word) {
          
         points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         flag6 = 1;
      }
      if (flag6 == 1) {
         temp_row = row;
         temp_column = column;
         while (i >= 0) {
            /* kuzey batı için */
            board_array[temp_row][temp_column] = 'x';		/* replace the word with x */
            temp_column--;
            temp_row--;
            i--;
         }
      }
      i = 0;
      temp_row = row;
      temp_column = column;
   }
   if (flag2 != 1 && flag1 != 1 && flag3 != 1 && flag4 != 1 && flag5 != 1 && flag6 != 1 && flag == 1) {
      while (board_array[temp_row][temp_column] == user_word[i]) {
         
         if (i == length_word)
            break;

         if (temp_column == SIZE)
            break;
         if (temp_row == SIZE)
            break;

         temp_column++;
         temp_row++;
         i++;
      }
      if (i == length_word) {
         
         points += 2;
         printf("you got 2 points. Your total points: %d \n", points);
         flag7 = 1;
      }

      if (flag7 == 1) {
         temp_row = row;
         temp_column = column;
         while (i >= 0) {
            
            board_array[temp_row][temp_column] = 'x';		/* replace the word with x */
            temp_column++;
            temp_row++;
            i--;
         }
      }
      i = 0;
      temp_row = row;
      temp_column = column;
   } else if (flag2 != 1 && flag1 != 1 && flag3 != 1 && flag4 != 1 && flag5 != 1 && flag6 != 1 && flag7 != 1 && flag == 1) {
      while (board_array[temp_row][temp_column] == user_word[i]) {
          

         if (i == length_word)
            break;
         if (temp_column == 0)
            break;
         if (temp_row == SIZE)
            break;
         temp_column--;
         temp_row++;
         i++;
      }
      if (i == length_word) {
        
         points += 2;
         printf("you got 2 points. Your total points: %d \n\n", points);
         flag8 = 1;
      }
      if (flag8 == 1) {
         temp_row = row;
         temp_column = column;
         while (i >= 0) {
             
            board_array[temp_row][temp_column] = 'x';	/* replace the word with x */
            temp_column--;
            temp_row++;
            i--;
         }
      }
      i = 0;
      temp_row = row;
      temp_column = column;
   }
   if (flag2 != 1 && flag1 != 1 && flag3 != 1 && flag4 != 1 && flag5 != 1 && flag6 != 1 && flag7 != 1 || (flag == 0)) {	/* check of user wrong */
      wrong++;
      if(wrong == 3){
      printf("you  lost!! your points is %d\n",points);
      }else{
      printf("Wrong choice! you have only %d lefts\n", 3 - wrong);
      }
   } 
   if (points == 14) {
      printf("you found all word!!!");
      printf("your point is 14\n");
   }
   flag=0; flag1 = 0; flag2 = 0; flag3 = 0; flag4 = 0; flag5 = 0; flag6 = 0; flag7 = 0; flag8 = 0;		/* reset the value for other words */
}
return 0;
}
int check_board(char board_array[SIZE][SIZE], char words_array[ROW][COLUMN], int rand_word, int diagnose, int row, int column) {	/*  check board  to places the word*/
   int sterlen, i = 0, check_row, check_column, length_word;
   length_word = strlen(words_array[rand_word]);

   if (diagnose == NORTH) {		/*places the word to north*/
       
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_row = row;
      while (board_array[check_row][column] == ' ') {
         if (check_row == 0)
            break;
         i++;
         check_row--;

      }
      if (i < length_word) 
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         row--;

      }
   } else if (diagnose == SOUTH) {		/*places the word to south*/
      /* güney */
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_row = row;
      while (board_array[check_row][column] == ' ') {
         if (check_row == SIZE - 1)
            break;
         i++;
         check_row++;

      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         row++;
      }
   } else if (diagnose == EAST) {		/*places the word to east*/

      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_column = column;
      while (board_array[row][check_column] == ' ') {
         if (check_column == SIZE - 1)
            break;

         i++;
         check_column++;

      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         column++;

      }
   } else if (diagnose == WEST) {			/*places the word to west*/
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_column = column;

      while (board_array[row][check_column] == ' ') {
         if (check_column == 0)
            break;
         i++;
         check_column--;
      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         column--;
      }
   } else if (diagnose == NORTHEAST) {		/*places the word to northeast*/
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_row = row;
      check_column = column;
      while (board_array[check_row][check_column] == ' ') {
         if (check_row == 0 || check_column == SIZE - 1)
            break;

         i++;
         check_row--;
         check_column++;

      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         column++;
         row--;
      }
   } else if (diagnose == NORTHWEST) {		/*places the word to northwest*/
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_row = row;
      check_column = column;
      while (board_array[check_row][check_column] == ' ') {
         if (check_row == 0 || check_column == 0)
            break;

         i++;
         check_row--;
         check_column--;

      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         column--;
         row--;

      }
   } else if (diagnose == SOUTHEAST) {		/*places the word to southeast*/
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_row = row;
      check_column = column;
      while (board_array[check_row][check_column] == ' ') {
         if (check_row == SIZE - 1 || check_column == SIZE - 1)
            break;
         i++;
         check_row++;
         check_column++;

      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         column++;
         row++;

      }
   } else if (diagnose == SOUTHWEST) {		/*places the word to southwest*/
      if (board_array[row][column] != ' ') {
         while (board_array[row][column] != ' ') {
            row = random_num(SIZE);
            column = random_num(SIZE);
         }
      }
      check_row = row;
      check_column = column;
      if (board_array[check_row][check_column] != ' ') {

      }
      while (board_array[check_row][check_column] == ' ') {

         if (check_row == SIZE - 1 || check_column == 0)
            break;
         i++;
         check_row++;
         check_column--;
      }
      if (i < length_word)
         return 0;

      i = 0;
      while (length_word > 0) {

         board_array[row][column] = words_array[rand_word][i];
         i++;
         length_word--;
         column--;
         row++;

      }
   }
   return 1;
}
int placement_word(char board_array[SIZE][SIZE], char words_array[ROW][COLUMN]) {  /* placing the word  */
   

   int diagnose, rand_word, row, column, flag = 0, flag1;
   row = random_num(SIZE);
   column = random_num(SIZE);
   diagnose = random_num(8);
   rand_word = random_num(ROW);

   switch (diagnose) {
   case NORTH:
      while (flag == 0) {

         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d\n", flag);
      }
      break;
   case SOUTH:
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d-\n", flag);
      }
      break;
   case EAST:
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);

         diagnose = random_num(8);
         printf("%d\n", flag);
      }
      break;
   case WEST:
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d \n", flag);
      }
      break;
   case NORTHEAST:
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d\n", flag);
      }
      break;
   case NORTHWEST:
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d\n", flag);
      }
      break;
   case SOUTHEAST:
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d\n", flag);
      }
      break;
   case SOUTHWEST:			
      while (flag == 0) {
         flag = check_board(board_array, words_array, rand_word, diagnose, row, column);
         diagnose = random_num(8);
         printf("%d\n", flag);
      }
      break;
   default:
      break;
   }
   return flag;
}

int random_num(int num) { /* rundom number generator*/
   return rand() % num;
}

void fill_board(char board_array[SIZE][SIZE]) { /*fill board array with blank*/
   /* 15x15 lik arrayı hazırlama  */
   for (int i = 0; i < SIZE; i++) {
      for (int k = 0; k < SIZE; k++) {
         board_array[i][k] = ' ';
      }
   }
}

void words_write_to_array(char words_array[ROW][COLUMN]) {   /*read word in a file and assign array */
   
   FILE * fp;
   fp = fopen("wordlist.txt", "r");
   int i = 0;
   while (fscanf(fp, "%s", words_array[i]) != EOF) {
      i++;
   }
}






