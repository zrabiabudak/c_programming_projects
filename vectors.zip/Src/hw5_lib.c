/*
** hw5_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/

#include <stdio.h>
#include "hw5_lib.h"


void operate_polynomials  (double* a3, double* a2, double* a1, double* a0, double* b3, double* b2, double* b1, double* b0, char op)
{
	printf("enter the first polynomial coefficient: ");
	getchar();
	scanf(" (3,%lf),(2,%lf),(1,%lf),(0,%lf)",a3,a2,a1,a0);
	getchar();
	printf("enter the second polynomial coefficient: ");
	getchar();
	scanf(" (3,%lf),(2,%lf),(1,%lf),(0,%lf)",b3,b2,b1,b0); 
	getchar();
	
	if(op=='+'){
		*a3=(*a1+*b1);
		*a2=(*a2+*b2);
		*a1=(*a1+*b1);
		*a0=(*a0+*b0);	
	}else if(op=='-'){
		*a3=(*a1-*b1);
		*a2=(*a2-*b2);
		*a1=(*a1-*b1);
		*a0=(*a0-*b0);		
	}else if(op=='*'){
		*a3=(*a3 * *b3);
		*a2=(*a3 * *b2)+(*b3* *a2);
		*a1=(*a3**b1)+(*a2**b2)+(*a1**b3);
		*a0=(*a3**b0)+(*a2**b1)+(*a1**b2)+(*a0**b3);
		*b3=(*a2**b0)+(*a1**b1)+(*a0**b2);
		*b2=(*a1**b0)+(*a0**b1);
		*b1=(*a0**b0);
	}
	
}


void four_d_vectors (double* mean_a0, double* mean_a1, double* mean_a2, double* mean_a3, double* longest_distance, int N)
{
	double d0, d1, d2, d3, euclidian_distance;
	while(N!=0){
	printf("enter the 4d vector  points");
	scanf("%lf %lf %lf %lf ",&d0,&d1,&d2,&d3);
	if(d0==-1 && d1==-1 && d2==-1 && d3==-1){
	printf("finish...!!! ");
     break;
	distance_between_4d_points (d0, d1, d2, d3, &euclidian_distance);
	N--;
}
		if(mean_a1!=0){
		*mean_a1=euclidian_distance;	
		}else if(mean_a2!=0){
		*mean_a2=euclidian_distance;	
		}else if(mean_a3!=0){
		*mean_a3=euclidian_distance;	
		}
	
   }
	
}


void distance_between_4d_points (double d0, double d1, double d2, double d3, double* euclidian_distance)
{
    
int temp0=0, temp1=0, temp2=0, temp3=0;

if(temp0==0){
temp0=d0;
temp1=d1;
temp2=d2;
temp3=d3;
}



}


void dhondt_method (int* partyA, int* partyB, int* partyC, int* partyD, int* partyE, int numberOfSeats)
{
	printf("TO BE IMPLEMENTED\n");
}


void order_2d_points_cc (double* x1, double* y1, double* x2, double* y2, double* x3, double* y3)
{
double slope_1,slope_2,slope_3,tempx=0.0,tempy=0.0;

printf("enter the coordinate of x  points x1,x2,x3");
scanf("%lf %lf %lf",x1,x2,x3);
printf("enter the coordinate of y  points y1,y2,y3");
scanf("%lf %lf %lf",y1,y2,y3);
slope_1=*y1/ *x1;
slope_2=*y2/ *x2;
slope_3=*y3/ *x3;
if(*x1>0 && *y1>0 && *x2>0 && *y2>0 && *x3>0 && *y3>0 ){   /* if first area  */
	if(slope_2>slope_1 && slope_2>slope_3 && slope_1>slope_3){/* slp2>slp1>slp3 */
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;

	}else if(slope_1>slope_2 && slope_1>slope_3 && slope_3>slope_2){/* slp1>slp3>slp2 */

		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_2>slope_3 && slope_2>slope_1 && slope_3>slope_1){/* slp2>slp3>slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3>slope_1 && slope_3>slope_2 && slope_1>slope_2){/* slp3>slp1>slp2 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3>slope_1 && slope_3>slope_2 && slope_2>slope_1){/* slp3>slp2>slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
	}





}else if(*x1<0 && *y1<0 && *x2<0 && *y2<0 && *x3<0 && *y3<0 ){/* if third area */

	if(slope_2>slope_1 && slope_2>slope_3 && slope_1>slope_3){/* slp2>slp1>slp3 */
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;

	}else if(slope_1>slope_2 && slope_1>slope_3 && slope_3>slope_2){/* slp1>slp3>slp2 */

		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_2>slope_3 && slope_2>slope_1 && slope_3>slope_1){/* slp2>slp3>slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3>slope_1 && slope_3>slope_2 && slope_1>slope_2){/* slp3>slp1>slp2 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3>slope_1 && slope_3>slope_2 && slope_2>slope_1){/* slp3>slp2>slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
	}



}else if(*x1<0 && *y1>0 && *x2<0 && *y2>0 && *x3<0 && *y3>0 ){/*if second area*/

	if(slope_2<slope_1 && slope_2<slope_3 && slope_1<slope_3){/* slp2<slp1<slp3 */
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;

	}else if(slope_1<slope_2 && slope_1<slope_3 && slope_3<slope_2){/* slp1<slp3<slp2 */

		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_2<slope_3 && slope_2<slope_1 && slope_3<slope_1){/* slp2<slp3<slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3<slope_1 && slope_3<slope_2 && slope_1<slope_2){/* slp3<slp1<slp2 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3<slope_1 && slope_3<slope_2 && slope_2<slope_1){/* slp3<slp2<slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
	}else if(*x1>0 && *y1<0 && *x2>0 && *y2<0 && *x3>0 && *y3<0 ){/*if fourth area*/

	if(slope_2<slope_1 && slope_2<slope_3 && slope_1<slope_3){/* slp2<slp1<slp3 */
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;

	}else if(slope_1<slope_2 && slope_1<slope_3 && slope_3<slope_2){/* slp1<slp3<slp2 */

		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_2<slope_3 && slope_2<slope_1 && slope_3<slope_1){/* slp2<slp3<slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x1;
		tempy=*y1;
		*x1=*x2;
		*y1=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3<slope_1 && slope_3<slope_2 && slope_1<slope_2){/* slp3<slp1<slp2 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
		tempx=*x3;
		tempy=*y3;
		*x3=*x2;
		*y3=*y2;
		*x2=tempx;
		*y2=tempy;
	}else if(slope_3<slope_1 && slope_3<slope_2 && slope_2<slope_1){/* slp3<slp2<slp1 */

		tempx=*x3;
		tempy=*y3;  
		*x3=*x1;
		*y3=*y1;
		*x1=tempx;
		*y1=tempy;
	}

}
}


}


void number_encrypt (unsigned char* number)
{
	char b7='-', b6='-', b5='-', b4='-', b3='-', b2='-', b1='-', b0='-';
	get_number_components (*number, &b7, &b6, &b5, &b4, &b3, &b2, &b1, &b0);
	reconstruct_components (number, b7, b6, b5, b4, b3, b2, b1, b0);
	printf("TO BE IMPLEMENTED\n");
}


void get_number_components (unsigned char number, char* b7, char* b6, char* b5, char* b4, char* b3, char* b2, char* b1, char* b0)
{
	printf("TO BE IMPLEMENTED\n");
}


void reconstruct_components (unsigned char* number, char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0)
{
	printf("TO BE IMPLEMENTED\n");
}
