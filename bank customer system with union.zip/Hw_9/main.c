#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define MAX 50
#include "util.h"

int main(){
int select=0,flag=0,flag2=0,counter=0,report;
float loan_array[50][3];						/* keep total loan of customer */

printf("============================================================\n");
printf("Welcome to the Bank Management System\n");
printf("============================================================\n");
printf("     1. List All Customers\n");
printf("     2. Add New Customer\n");
printf("     3. New Loan Application\n");
printf("     4. Report Menu\n");
printf("     5. Exit System\n");

	for(int i=0;i<50;i++){			/* fill the temp loan array with zero */
		for(int t=0;t<3;t++){
		loan_array[i][t]=0.0;
		}
	}
  while(select!=5){
    while(flag!=1){
	  flag=scanf("%d",&select);
	  getchar();
    }flag=0;
	switch(select){
	case 1:
	listCustomers(counter);
	break;
	case 2:
	flag=1;
	addCustomer(counter);			/* file is fill the customer */	
	counter++;
	break;
	case 3:
	flag2=1;
	newLoan (counter);
	break;
	case 4:
	printf("which file do you want to report (1) customer.txt and (2) loan.txt\n");
	scanf("%d",&report);
		if(report==1 && flag==1){  /* if file is not empty */
		getReport();
		}else if(report==2 && flag2==1){
		getReport2();
		}else{
		printf("files empty please select from menü \n");
		}
	break;
	case 5:				/* user exit programe */
         printf("exit\n");
	break;
	default:
	break;
	}
  }
}
