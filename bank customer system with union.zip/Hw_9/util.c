#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define MAX 50
#include "util.h"


union Person
{
	char address[50];
	int phone;
	char name[50];
};
union Loan
{
	float amount;
	float interestRate;
	int period;
};
struct BankAccount
{
	union Person Customer;
	union Loan Loans[3];
};
struct BankAccount custom[MAX];


float loan_array[50][3];	/* keep total loan of customer */
void getReport2(){
int counter=0;
FILE *fp2;
fp2=fopen("loan.txt","r+");
char ch[50];
		printf("\n");
		while((fscanf(fp2,"%s",ch))!=EOF){
			counter++;
			if(counter%4==0)		/* new line  */
			printf("\n");
			printf("%s ",ch);
		}
	printf("\n\nenter select from menu\n");
	fclose(fp2);
}

void getReport(){
float total=0.0;
int cont=0,i=0,flag=0,flag2=0;
char  ch;
FILE *fp;
fp=fopen("customer.txt","r");
printf("\nCustomer Address = ");

ch = fgetc(fp);
printf("%c",ch);

do{
	ch = fgetc(fp);
	
	if(ch!=EOF)		/*if ch is equal to the EOF , this line prevents it  from rotating 1 more time.*/
	printf("%c",ch);
	
	if(ch==' ' && flag==0 && flag2==0){
	printf("\nCustomer phone = ");
	flag=1;
	}else if(ch==' ' && flag==1){
	printf("\nCustomer name = ");
	}if(ch=='\n' && flag==1){
		flag2=1;
		flag=0;
		i=0;
		while(i<3 && flag==0){     /* the customer can not take more than 3 loans from the bank. */

	   	      if(loan_array[cont][i]==0.0){		 /* loan array */
			    flag=1;
			    break;
			 }if(loan_array[cont][i]>0.0 && i==0 ){
			  printf("\nCustomer loan = ");
			  printf("[ %f ",loan_array[cont][i]);
			  total+=loan_array[cont][i];
			  i++;
			 }if(loan_array[cont][i]>0.0 ){
			  printf("+ %f",loan_array[cont][i]);
			  total+=loan_array[cont][i];
			  i++;
			}
		}
		if(total>0.0){
		printf("] => %f",total);
		total=0;
		}else{
		printf("Customer has no loan\n");
		}
		flag=0;
			cont++;
	}if(flag2==1 && ch==' '){
	printf("\n\n\nCustomer Address =");
	flag2=0;
	}
	}while(ch!=EOF); 				/* read  customer.txt file until end of file   */
	printf("\nPlease enter a select\n");
	fclose(fp);
}
void newLoan(int counter){

FILE *fp2;
fp2=fopen("loan.txt","a+");

FILE *fp;
fp=fopen("customer.txt","r+");

char custname[50],is_in_file[50];
float amount,interestRate,Loan=1.0;
int period,k=0,i=0,flag=0,cont=0,temp;

printf("which customer will you give  loans to?\n");
scanf("%[^\n]%*c",custname);

while(fscanf(fp,"%s",is_in_file)!=EOF){ 	/* read file until end of file */
			cont++;
		if(strcmp(is_in_file,custname)==0){	/* to check whether the customer is in file */
		flag=1;
			break;
		}
	}cont=cont/3-1; 		/* because there are 3 words in each line.and I printed it in order, I divided the order of each word from the name into 3 */	
		
	
	if(flag==1){
	printf("Enter the period of loan:\n ");
	scanf("%d",&custom[i].Loans[k].period);
	period=custom[i].Loans[k].period;
	printf("5%d",period);
	printf("Enter the interestRate of loan:\n");
	scanf("%f",&custom[i].Loans[k].interestRate);
	interestRate=custom[i].Loans[k].interestRate;
	printf("Enter the amount of loan:\n ");
	scanf("%f",&custom[i].Loans[k].amount);
	amount=custom[i].Loans[k].amount;
	Loan=calculateLoan(amount,period,interestRate,Loan);		/* recursive function */
	fprintf(fp2,"%s",custname);						/* save to loan.txt name */
	fprintf(fp2,"\n");
	temp=1;
	fprintf(fp2,"Total credit value = %f\n",Loan);
	while(temp<=period){
	fprintf(fp2,"%d. month instalment = %f\n",temp,Loan/(float)period);		/* save to loan.txt  */
	temp++;
	}
		if(loan_array[cont][0]==0.0){
		loan_array[cont][0]=Loan;
		printf("loan added succesfully  please enter a select from menu \n");
		}else if(loan_array[cont][1]==0.0){
		printf("loan added succesfully  please enter a select \n");
		loan_array[cont][1]=Loan;
		}else if(loan_array[cont][2]==0.0){
		printf("loan added succesfully  please enter a select \n");
		loan_array[cont][2]=Loan;
		}
	
	}else{
	printf("Customer is not find please enter a select\n");
	}
	fclose(fp);
}

float calculateLoan(float amount, int period, float interestRate,float Loan){ 	/*recursive function to calculate loan*/
 
	if(period>0){
	Loan=Loan*(1+interestRate);
	return calculateLoan(amount,period-1,interestRate,Loan);  			/* this  formül  into the  pdf  */
}else{
Loan=amount*Loan; 								/* if period equal to zero return loan  */
return Loan;
}
}	


void listCustomers(int counter){		/* list the customer name into union  */
	 
	int flag=0;
 
	for(int i=0;i<counter;i++){
		printf("%d.Customer Name: %s\n",i+1,custom[i].Customer.name);
		flag=1;
	}if(flag==0){
	printf("Not a customer please enter the 2 select from menu and add a customer \n");
	}
 
}

void addCustomer (int counter){
FILE *fp;
fp=fopen("customer.txt","a+");

printf("please enter your address:");
scanf("%[^\n]%*c",custom[counter].Customer.address); 	/*  union adress  */
fprintf(fp," %s",custom[counter].Customer.address);
printf("%s",custom[counter].Customer.address);
printf("please enter your phone:");
scanf("%d",&custom[counter].Customer.phone);		/*  union phone  */
fprintf(fp," %d",custom[counter].Customer.phone);
printf("please enter your name:");
getchar();
scanf("%[^\n]%*c",custom[counter].Customer.name);		/*  union name  */
fprintf(fp," %s",custom[counter].Customer.name);
fprintf(fp,"\n");
printf("succesful added please enter a select from menu \n");
fclose(fp);
}

