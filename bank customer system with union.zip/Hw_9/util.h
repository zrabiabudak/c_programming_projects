#ifndef _UTIL_H_
#define _UTIL_H_


void listCustomers(int counter);
void addCustomer (int counter);
void newLoan (int counter);
float calculateLoan(float amount, int period, float interestRate,float Loan);
void getReport();
void getReport2();

#endif /* _UTIL_H_ */
